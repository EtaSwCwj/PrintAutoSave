﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace PrintAutoSave
{
    public partial class Form1: Form
    {
        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Process[] processes = Process.GetProcessesByName("mspaint");

            if (processes.Length == 0)
            {
                MessageBox.Show("그림판이 실행 중이지 않습니다.", "알림", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 첫 번째 그림판 프로세스를 대상으로 함
            IntPtr hWnd = processes[0].MainWindowHandle;

            if (hWnd == IntPtr.Zero)
            {
                MessageBox.Show("그림판 창을 찾을 수 없습니다.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 그림판 창을 앞으로 가져오고 Ctrl + S 키 전송
            SetForegroundWindow(hWnd);
            System.Threading.Thread.Sleep(200); // 창 전환 딜레이

            SendKeys.SendWait("^s"); // Ctrl + S
        }
    }
}
