﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace PrintAutoSave
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        private Process selectedProcess = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void SaveCommand()
        {
            if (selectedProcess == null || selectedProcess.HasExited)
                return;

            IntPtr hWnd = selectedProcess.MainWindowHandle;

            if (hWnd == IntPtr.Zero)
                return;

            SetForegroundWindow(hWnd);
            System.Threading.Thread.Sleep(200);
            SendKeys.SendWait("^s"); // Ctrl + S
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (FormProcessSelect selectForm = new FormProcessSelect())
            {
                var result = selectForm.ShowDialog(this);

                if (result == DialogResult.OK && selectForm.SelectedProcess != null)
                {
                    selectedProcess = selectForm.SelectedProcess;
                    timerAutoSave.Start();
                    MessageBox.Show($"선택된 그림판 PID: {selectedProcess.Id}\n10초마다 저장이 시작됩니다.");
                }
                else
                {
                    MessageBox.Show("선택이 취소되었습니다.");
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (selectedProcess != null &&
                !selectedProcess.HasExited &&
                selectedProcess.ProcessName.ToLower() == "mspaint")
            {
                SaveCommand();
            }
        }
    }
}

